package com.example.app_professor.area_do_aluno;

public class Construtor {

    private String item_lista_aluno;

    public Construtor (String item_lista_aluno){
        this.item_lista_aluno = item_lista_aluno;
    }

    String getItem_lista_aluno(){
        return item_lista_aluno;
    }
}
