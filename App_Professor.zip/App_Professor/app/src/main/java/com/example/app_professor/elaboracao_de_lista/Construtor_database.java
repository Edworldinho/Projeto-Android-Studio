package com.example.app_professor.elaboracao_de_lista;

public class Construtor_database {

    private String pppp;

    private Boolean acheck;
    private String atext;

    private Boolean bcheck;
    private String btext;

    private Boolean ccheck;
    private String ctext;

    private Boolean dcheck;
    private String dtext;

    Construtor_database(String pppp, Boolean acheck, String atext, Boolean bcheck, String btext, Boolean ccheck, String ctext, Boolean dcheck, String dtext) {

        this.pppp = pppp;
        this.acheck = acheck;
        this.atext = atext;
        this.bcheck = bcheck;
        this.btext = btext;
        this.ccheck = ccheck;
        this.ctext = ctext;
        this.dcheck = dcheck;
        this.dtext = dtext;
    }

    public String getPppp() {
        return pppp;
    }

    public Boolean getAcheck() {
        return acheck;
    }

    public String getAtext() {
        return atext;
    }

    public Boolean getBcheck() {
        return bcheck;
    }

    public String getBtext() {
        return btext;
    }

    public Boolean getCcheck() {
        return ccheck;
    }

    public String getCtext() {
        return ctext;
    }

    public Boolean getDcheck() {
        return dcheck;
    }

    public String getDtext() {
        return dtext;
    }
}
