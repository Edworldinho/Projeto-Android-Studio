package com.example.app_professor.area_do_professor;

public class Construtor {

    private String item_lista_prof;

    public Construtor(String item_lista_prof) {
        this.item_lista_prof = item_lista_prof;
    }

    String getItem_lista_prof() {
        return item_lista_prof;
    }
}
